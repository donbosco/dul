package pelib.filters;

public abstract class ConvolutionKernel1D
{
  public abstract float getWeight(float paramFloat);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     pelib.filters.ConvolutionKernel1D
 * JD-Core Version:    0.6.2
 */