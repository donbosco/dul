package pelib.filters;

import pelib.ImageColour;

public abstract class Filter
{
  public abstract void filter(ImageColour paramImageColour1, ImageColour paramImageColour2);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     pelib.filters.Filter
 * JD-Core Version:    0.6.2
 */