/*    */ package pelib;
/*    */ 
/*    */ public class BeginEraseCommand extends Command
/*    */ {
/*    */   public BeginEraseCommand()
/*    */   {
/* 12 */     super(null);
/*    */   }
/*    */ 
/*    */   public void undo(Area dirty)
/*    */   {
/* 20 */     //if (!$assertionsDisabled) throw new AssertionError();
/*    */   }
/*    */ 
/*    */   public void execute(Area dirty)
/*    */   {
/* 28 */    // if (!$assertionsDisabled) throw new AssertionError();
/*    */   }
/*    */ }

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     pelib.BeginEraseCommand
 * JD-Core Version:    0.6.2
 */