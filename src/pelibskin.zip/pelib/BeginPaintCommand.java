/*    */ package pelib;
/*    */ 
/*    */ public class BeginPaintCommand extends Command
/*    */ {
/*    */   public BeginPaintCommand()
/*    */   {
/* 13 */     super(null);
/*    */   }
/*    */ 
/*    */   public void undo(Area dirty)
/*    */   {
/* 21 */     //if (!$assertionsDisabled) throw new AssertionError();
/*    */   }
/*    */ 
/*    */   public void execute(Area dirty)
/*    */   {
/* 29 */     //if (!$assertionsDisabled) throw new AssertionError();
/*    */   }
/*    */ }
