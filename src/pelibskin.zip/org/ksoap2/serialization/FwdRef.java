package org.ksoap2.serialization;

class FwdRef
{
  FwdRef next;
  Object obj;
  int index;
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     org.ksoap2.serialization.FwdRef
 * JD-Core Version:    0.6.2
 */