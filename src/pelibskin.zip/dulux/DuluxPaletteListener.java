package dulux;

public abstract interface DuluxPaletteListener
{
  public abstract void colourSelected(DuluxColour paramDuluxColour);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     dulux.DuluxPaletteListener
 * JD-Core Version:    0.6.2
 */