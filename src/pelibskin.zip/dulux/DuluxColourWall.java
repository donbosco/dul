/*    */ package dulux;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class DuluxColourWall
/*    */ {
/*    */   private static int rows;
/*    */   private static int columns;
/*    */   private static int offset;
/*    */   private static int chipWidth;
/*    */   private static int chipHeight;
/*    */   private static Vector colourWall;
/*    */ 
/*    */   public void addColour(DuluxColour dc)
/*    */   {
/*    */   }
/*    */ 
/*    */   public DuluxColour getColour(int row, int column)
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */   public DuluxColour[][] getHue(int hueNumber) {
/* 35 */     return (DuluxColour[][])null;
/*    */   }
/*    */ }

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     dulux.DuluxColourWall
 * JD-Core Version:    0.6.2
 */