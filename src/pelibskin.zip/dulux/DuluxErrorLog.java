package dulux;

public abstract interface DuluxErrorLog
{
  public abstract void log(String paramString);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     dulux.DuluxErrorLog
 * JD-Core Version:    0.6.2
 */