/*    */ package dulux;
/*    */ 
/*    */ import java.awt.Point;
/*    */ 
/*    */ public class DuluxSelectionDraw
/*    */ {
/*    */   public void draw(Point p)
/*    */   {
/* 16 */     int x = (int)p.getX();
/* 17 */     int y = (int)p.getY();
/*    */   }
/*    */ }

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     dulux.DuluxSelectionDraw
 * JD-Core Version:    0.6.2
 */