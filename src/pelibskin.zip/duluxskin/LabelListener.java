package duluxskin;

public abstract interface LabelListener
{
  public abstract void itemRenamed(LabelEvent paramLabelEvent, SkinnedLabel paramSkinnedLabel, String paramString);

  public abstract void itemSelected(LabelEvent paramLabelEvent);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     duluxskin.LabelListener
 * JD-Core Version:    0.6.2
 */