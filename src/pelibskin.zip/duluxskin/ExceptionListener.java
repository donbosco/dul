package duluxskin;

public abstract interface ExceptionListener
{
  public abstract void exceptionOccured(Skin paramSkin, Throwable paramThrowable);
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     duluxskin.ExceptionListener
 * JD-Core Version:    0.6.2
 */