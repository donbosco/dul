/*    */ package pelibskin;
/*    */ 
/*    */ import java.awt.AWTEvent;
/*    */ 
/*    */ public class ListEvent extends AWTEvent
/*    */ {
/*    */   public static final int ITEM_SELECTED = 65537;
/*    */   public static final int LIST_MODIFIED = 65538;
/*    */   public static final int ITEM_HIGHLIGHTED = 65539;
/*    */   public static final int ITEM_RENAMED = 65540;
/*    */ 
/*    */   public ListEvent(SkinnedList source, int id)
/*    */   {
/* 39 */     super(source, id);
/*    */   }
/*    */ }

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     pelibskin.ListEvent
 * JD-Core Version:    0.6.2
 */