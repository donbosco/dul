/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class ImageAccessException extends JimiException
/*    */ {
/*    */   public ImageAccessException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ImageAccessException(String paramString)
/*    */   {
/* 29 */     super(paramString);
/*    */   }
/*    */ }
