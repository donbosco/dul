package com.sun.jimi.core;

public abstract class JimiEncoderFactorySupport
  implements JimiEncoderFactory
{
  public abstract boolean canEncodeMultipleImages();

  public abstract JimiEncoder createEncoder();

  public abstract String[] getFilenameExtensions();

  public abstract String getFormatName();

  public abstract String[] getMimeTypes();
}
