/*    */ package com.sun.jimi.core.options;
/*    */ 
/*    */ import com.sun.jimi.core.JimiException;
/*    */ 
/*    */ public class OptionException extends JimiException
/*    */ {
/*    */   public OptionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OptionException(String paramString)
/*    */   {
/* 33 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     com.sun.jimi.core.options.OptionException
 * JD-Core Version:    0.6.2
 */