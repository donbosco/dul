/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class JimiLicenseInformation
/*    */ {
/*    */   public static boolean isCrippled()
/*    */   {
/* 29 */     return Jimi.crippled;
/*    */   }
/*    */ 
/*    */   public static boolean isLimited()
/*    */   {
/* 24 */     return Jimi.limited;
/*    */   }
/*    */ }

