/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class NoImageAvailException extends JimiException
/*    */ {
/*    */   public NoImageAvailException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NoImageAvailException(String paramString)
/*    */   {
/* 25 */     super(paramString);
/*    */   }
/*    */ }
