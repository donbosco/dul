package com.sun.jimi.core.util;

public abstract interface FreeFormat
{
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     com.sun.jimi.core.util.FreeFormat
 * JD-Core Version:    0.6.2
 */