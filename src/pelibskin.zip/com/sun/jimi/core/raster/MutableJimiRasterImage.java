package com.sun.jimi.core.raster;

import com.sun.jimi.core.MutableJimiImage;

public abstract interface MutableJimiRasterImage extends JimiRasterImage, MutableJimiImage
{
}

/* Location:           C:Documents and Settings user My DocumentsDownloadsdulux-signed.jar
 * Qualified Name:     com.sun.jimi.core.raster.MutableJimiRasterImage
 * JD-Core Version:    0.6.2
 */