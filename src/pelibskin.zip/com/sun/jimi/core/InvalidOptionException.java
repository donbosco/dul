/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class InvalidOptionException extends JimiException
/*    */ {
/*    */   public InvalidOptionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidOptionException(String paramString)
/*    */   {
/* 25 */     super(paramString);
/*    */   }
/*    */ }
