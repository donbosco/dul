package com.sun.jimi.core;

public abstract interface FormatFactory
{
  public abstract String[] getFilenameExtensions();

  public abstract String getFormatName();

  public abstract String[] getMimeTypes();
}
