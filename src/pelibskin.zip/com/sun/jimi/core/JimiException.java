/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class JimiException extends Exception
/*    */ {
/*    */   public JimiException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public JimiException(String paramString)
/*    */   {
/* 33 */     super(paramString);
/*    */   }
/*    */ }
