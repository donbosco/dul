package com.sun.jimi.core;

public abstract interface JimiEncoderFactory extends FormatFactory
{
  public abstract boolean canEncodeMultipleImages();

  public abstract JimiEncoder createEncoder();
}
