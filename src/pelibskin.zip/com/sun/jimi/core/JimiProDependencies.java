package com.sun.jimi.core;

class JimiProDependencies
{
}

