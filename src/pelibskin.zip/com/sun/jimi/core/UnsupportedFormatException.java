/*    */ package com.sun.jimi.core;
/*    */ 
/*    */ public class UnsupportedFormatException extends JimiException
/*    */ {
/*    */   public UnsupportedFormatException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UnsupportedFormatException(String paramString)
/*    */   {
/* 25 */     super(paramString);
/*    */   }
/*    */ }
