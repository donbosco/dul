package com.sun.jimi.core;

public abstract interface JimiDecoderFactory extends FormatFactory
{
  public abstract JimiDecoder createDecoder();

  public abstract byte[][] getFormatSignatures();
}
