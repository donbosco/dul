package com.sun.jimi.core;

public abstract interface JimiExtension
{
  public abstract JimiDecoderFactory[] getDecoders();

  public abstract String getDescription();

  public abstract JimiEncoderFactory[] getEncoders();

  public abstract String getVendor();

  public abstract String getVersionString();
}
