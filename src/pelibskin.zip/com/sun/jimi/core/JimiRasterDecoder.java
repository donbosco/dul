package com.sun.jimi.core;

public abstract interface JimiRasterDecoder extends JimiDecoder
{
}

