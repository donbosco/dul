/*     */ package com.sun.jimi.core;
/*     */ 
/*     */ class JimiMultiImageRasterDecoderRunner
/*     */   implements Runnable
/*     */ {
/*     */   JimiMultiImageRasterDecoder decoder;
/*     */ 
/*     */   public JimiMultiImageRasterDecoderRunner(JimiMultiImageRasterDecoder paramJimiMultiImageRasterDecoder)
/*     */   {
/* 203 */     this.decoder = paramJimiMultiImageRasterDecoder;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 208 */     this.decoder.driveDecoding();
/*     */   }
/*     */ }

